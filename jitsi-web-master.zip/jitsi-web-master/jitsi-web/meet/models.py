from flask_login import UserMixin
import datetime
from . import db

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True) 
    username = db.Column(db.String(100), unique=True)
    password = db.Column(db.String(100),nullable=False)
    force_change = db.Column(db.Boolean(),nullable=False,default=1)
    firstname = db.Column(db.String(1000))
    lastname = db.Column(db.String(1000))
    email = db.Column(db.String(1000))
    phone = db.Column(db.String(1000))
    photo = db.Column(db.LargeBinary(length=None))
    role = db.Column(db.String(1000))

class Meetings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(1000), unique=True)
    password = db.Column(db.String(100))
    owner = db.Column(db.String(100))
    #date = db.Column(db.DateTime, nullable=False, default=datetime.datetime.utcnow)
    date = db.Column(db.DateTime(timezone=True), nullable=False,  default=datetime.datetime.now())
    startdatetime = db.Column(db.DateTime(timezone=True))
    enddatetime = db.Column(db.DateTime(timezone=True))
    participantcount = db.Column(db.Integer)

class Guests(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100),nullable=False)
    email = db.Column(db.String(100),nullable=False)
    meetingid = db.Column(db.Integer(),nullable=False)
    date = db.Column(db.DateTime, nullable=False, default=datetime.datetime.utcnow)

class Token:
    def generate(self,appid,appsecret,roomname,firstname,email,id,group,avatar,moderator):
        import jwt, datetime
        template = {
                "context": {
                    "user": {
                    "avatar": "https:/gravatar.com/avatar/abc123",
                    "name": "",
                    "email": "",
                    "id": "abcd:a1b2c3-d4e5f6-0abc1-23de-abcdef01fedcba"
                    },
                "group": "a123-123-456-789"
                    },
                "aud": "",
                "iss": "",
                "sub": "meet.jitsi",
                "room": "",
                "exp":  100,
                "moderator": "false" }
        template['aud']  = appid
        template['iss'] = appid
        template['moderator'] = moderator
        if not avatar:
            template['context']['user']['avatar'] = avatar
        template['context']['user']['name'] = firstname
        template['context']['user']['email'] = email
        if not id:
            template['context']['user']['id'] = id
        if not group:
            template['context']['group'] = group
        template['room'] = roomname
        template['exp'] = datetime.datetime.utcnow() + datetime.timedelta(seconds=20)
        return jwt.encode(template, appsecret, algorithm='HS256').decode('utf-8')

class Validation:
    def email(self,email):
        from email_validator import validate_email, EmailNotValidError
        try:
            valid = validate_email(email)
            return True
        except EmailNotValidError as e:
            return False
    def empty(self,value):
        if not value or value == "":
            return False
        else:
            return True
    def length(self,value,length):
        if len(value) < length:
            return False
        else:
            return True 
    def datetime_(self, value):
        date_format = '%d-%m-%Y %H:%M %p'
        try:
            date_obj = datetime.datetime.strptime(value, date_format)
            return True
        except ValueError:
            return False
    def comparedates(self,stdt,endt):
        if stdt < endt:
            return True
        else:
            return False     

    
    
