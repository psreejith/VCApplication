from . import db
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from .models import User
from .models import Meetings
from .models import Token
from .models import Validation
import random, string, re, base64
import webbrowser
import datetime

main = Blueprint('main', __name__) 

@main.route('/')
@login_required
def index():
    from flask import current_app
    user = User.query.filter_by(username=current_user.username).first()
    if user.force_change != 0:
        return redirect(url_for('main.profile'))
    try:
        avatar = user.firstname[0].upper() + user.lastname[0].upper()
    except:
        avatar = current_user.username[0].upper()
    password = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5)) 
    public_url = current_app.config['EXTERNAL_URL']
    guest_link = public_url + url_for('auth.guest_without_room') + "/"
    users = User.query.all()
    return render_template('room.html',avatar=avatar,meeting=True,meeting_password=password,guest_link=guest_link, users = users)

@main.route('/', methods=['POST'])
@login_required
def start_meeting():
    roomname = request.form.get('roomname')
    password = request.form.get('meetingpassword')
    roomname = re.sub('\W+','', roomname) 
    valid = Validation()
    if valid.length(roomname,5) == False:
        flash("Please enter a valid room name with minimun five letters")
        return redirect(url_for('main.index'))
    meet = Meetings.query.filter_by(name=roomname).first()
    if meet:
        if meet.owner != current_user.username :
            flash('Meeting room already in use.')
            return redirect(url_for('main.index'))
        else:
            meet.password = password
            db.session.commit()
    else:
        meeting = updatemeeting(roomname,password )
    return redirect(url_for('main.meeting',roomname=roomname))

def updatemeeting(roomname,password ):
    username = current_user.username
    roomname = re.sub('\W+','', roomname)
    new_meeting = Meetings(name=roomname,owner=username, password=password   )
    db.session.add(new_meeting)
    db.session.commit()

def convert(date_time):  
    datetime_str = datetime.datetime.strptime(date_time, '%Y-%m-%d %H:%M')    
    return datetime_str 

def getallmeetings():    
    meetings = Meetings.query.all()
    for meeting in meetings:
        print (meeting.id,meeting.name,meeting.password, meeting.owner, meeting.date, meeting.participantcount)
 
@main.route('/schedules')
def schedules():
    user = User.query.filter_by(username=current_user.username).first()
    try:
        avatar = user.firstname[0].upper() + user.lastname[0].upper()
    except:
        avatar = current_user.username[0].upper()
    meetings = Meetings.query.all()    
    return render_template ('schedules.html',avatar=avatar,meetings=meetings)

@main.route('/profile')
@login_required
def profile():  
    user = User.query.filter_by(username=current_user.username).first()
    firstlogin = None
    try:
        avatar = user.firstname[0].upper() + user.lastname[0].upper()
    except:
        avatar = current_user.username[0].upper()
    if user.force_change != 0:
        firstlogin = True
    try:
        if not user.photo:
            photo = None
        else:
            photo = "data:;base64," + base64.b64encode(user.photo).decode("utf-8")
    except:
        photo = None
    return render_template('profile.html',firstname=user.firstname,lastname=user.lastname,email=user.email,phone=user.phone,avatar=avatar,firstlogin=firstlogin,photo=photo)

@main.route('/profile', methods=['POST'])
@login_required
def profile_post():
    user = User.query.filter_by(username=current_user.username).first()
    firstname = request.form.get('firstname')
    lastname = request.form.get('lastname')
    email = request.form.get('email')
    phone = request.form.get('phone')
    password = request.form.get('password')
    if 'photo' not in request.files:
       return redirect(request.url)
    photo = request.files['photo']

    valid = Validation()
    err = 0
    if user.force_change != 0:
        if not password :
            flash('Password change is required')
            err = 1
        elif check_password_hash(user.password, password) == True:
            flash('You can not use previous password.')
            err = 1
        else:
            user.password = generate_password_hash(password, method='sha256')
    else:
        if password != "":
            if not check_password_hash(user.password, password):
                user.password = generate_password_hash(password, method='sha256')
    
    if not firstname or not lastname :
        flash('Please fill your firstname and lastname.')
        err = 1
    if valid.email(email) == False:
        flash('Invalid email address.')
        err = 1
    user.firstname = firstname
    user.lastname = lastname
    user.email = email
    user.phone = phone
    user.photo = photo.read()
    db.session.commit()
    #flash('Profile updated successfully.')           #sree [07-05-2020]
    if err == 0 :
        user.force_change = 0
        db.session.commit()
        return redirect(url_for('main.index'))
    else:
        return redirect(url_for('main.profile'))

@main.route("/meeting")
@login_required
def room_null():
    return redirect(url_for('main.index'))

@main.route("/meeting/<roomname>",methods=['GET'])
@login_required
def meeting(roomname):
    from flask import current_app
    user = User.query.filter_by(username=current_user.username).first()
    status = request.args.get('status')
    avatar = user.firstname[0].upper() + user.lastname[0].upper()
    avatarurl = ""
    group = ""
    appid = current_app.config['APP_ID']
    appsecret = current_app.config['APP_SECRET']
    moderator = True
    token = Token()
    roomname = re.sub('\W+','', roomname)
    try:
        avatarurl = "data:;base64," + base64.b64encode(user.photo).decode("utf-8")
    except:
        avatarurl = ""
    jwt = token.generate(appid,appsecret,roomname,user.firstname,user.email,user.id,group,avatarurl,moderator)

    # sree [08-05-2020]
    meet = Meetings.query.filter_by(name=roomname).first() 
    public_url = current_app.config['EXTERNAL_URL']
    guest_link = public_url + url_for('auth.guest_without_room') + "/" 
    return render_template( 'meeting.html',avatar=avatar,condition=True,roomname=roomname,token=jwt,meeting_password=meet.password,guest_link=guest_link)
    #return render_template('room.html')
 
@main.route('/static/<path:path>')
def send_js(path):
    return send_from_directory('static', path)


@main.route('/modifymeetings')
def modifymeetings():
    avatar = current_user.firstname[0].upper()+current_user.lastname[0].upper()
    meetings = Meetings.query.all()
    users = User.query.all()
    return render_template ('modifymeetings.html',avatar=avatar,meetings=meetings,users = users)

@main.route('/modifymeetings',methods=['POST'])
def modifymeetings_post():
    id = request.form.get('idVal')
    action = request.form.get('action')
    valid = Validation()
    #print(id, ' ' + action)
    if action == 'delete':
        meeting = Meetings.query.filter_by(id=id).first()
        db.session.delete(meeting)
        db.session.commit()
        flash('Meeting deleted successfully.')
    elif action == 'edit':
        name = request.form.get('meetingname')
        participantcount = request.form.get('participantcount')
        startdatetime = request.form.get('startdatetime')
        enddatetime = request.form.get('enddatetime')
        # update meeting
        meeting = Meetings.query.filter_by(id=id).first()
        meeting.owner = current_user.username
        meeting.participantcount = participantcount
        meeting.startdatetime = convert_(startdatetime)
        meeting.enddatetime = convert_(enddatetime)
        meeting.date = datetime.datetime.now()
        db.session.flush()
        db.session.commit()     
        flash('Meeting edited successfully.')
    elif action == 'add':
        name = request.form.get('addmeetingname')
        meeting = Meetings.query.filter_by(name=name).first()        
        participantcount = request.form.get('addparticipantcount')
        startdatetime = request.form.get('addstartdatetime')
        enddatetime = request.form.get('addenddatetime')
        if meeting :
            flash("Meeting exists. Please schedule with another meeting name")
        elif valid.datetime_(startdatetime) == False or valid.datetime_(enddatetime) == False:
            flash("Invalid Meeting Start or End Date Time") 
        elif valid.comparedates(startdatetime,enddatetime) == False:
            flash("Meeting Start Date Time should be less than Meeting End Date Time")  
        else :            
            owner = current_user.username 
            password = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5)) 
            newmeeting = Meetings(name=name,password=password,owner=owner,startdatetime=convert_(startdatetime),enddatetime=convert_(enddatetime),participantcount=participantcount)
            db.session.add(newmeeting)
            db.session.commit()

    avatar = current_user.firstname[0].upper()+current_user.lastname[0].upper()
    meetings = Meetings.query.all()
    return render_template ('modifymeetings.html',avatar=avatar,meetings=meetings)

def convert_(date_time):  
    datetime_str = datetime.datetime.strptime(date_time, '%d-%m-%Y %H:%M %p')    
    return datetime_str 