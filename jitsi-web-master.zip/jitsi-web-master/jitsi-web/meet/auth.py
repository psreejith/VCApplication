from flask import Blueprint, render_template, redirect, url_for, request, flash
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_manager, login_user, logout_user, login_required, current_user
from .models import User
from .models import Token
from .models import Meetings
from .models import Guests
from .models import Validation
from . import db
import random, urllib.parse, re

auth = Blueprint('auth', __name__)

@auth.route('/login')
def login():
    return render_template('login.html')

@auth.route('/login', methods=['POST'])
def login_post():
    username = request.form.get('username')
    password = request.form.get('password')
    remember = True if request.form.get('remember') else False
    user = User.query.filter_by(username=username).first()
    if not user or not check_password_hash(user.password, password):
        flash('Please check your login details and try again.')
        return redirect(url_for('auth.login'))
    login_user(user, remember=remember)
    if user.force_change != 0:
        return redirect(url_for('main.profile'))
    else:
        return redirect(url_for('main.index'))


# sree[09-05-2020]
@auth.route('/users')
@login_required
def users():         
    users = User.query.all()     
    avatar = current_user.firstname[0].upper() + current_user.lastname[0].upper()
    return render_template('users.html',users=users, title="Registered Users",avatar=avatar)
# sree

@auth.route('/users', methods=['POST'])
@login_required
def users_post():
    action = request.form.get('action')
    idVal = request.form.get('idVal')
    print(idVal,action)
    if  action == "deleteuser":
        delete_user=User.query.filter(User.id == idVal).first()
        db.session.delete(delete_user)
        db.session.commit()
        flash('User deleted successfully.')
        #User.query.filter_by(id=idVal).delete()
    elif  action  == "edituser":    
        fname = request.form.get('editfirstname')
        lname = request.form.get('editlastname')
        uname = request.form.get('editusername')
        phone = request.form.get('editphoneno')
        email = request.form.get('editemail')
        pwd = request.form.get('editpassword')
        role = request.form.get('editrole')
        if pwd != '':
            pwd = generate_password_hash(pwd, method='sha256')
        edituser = User.query.filter(User.id == idVal).first() 
        edituser.firstname = fname
        edituser.lastname = lname
        #edituser.username = uname
        edituser.phone = phone
        edituser.email = email
        edituser.role=role
        db.session.flush()
        db.session.commit()        
        flash('User edited successfully.')
    elif action == 'adduser':
        fname = request.form.get('firstname')
        lname = request.form.get('lastname')
        uname = request.form.get('username')
        new_user = User.query.filter_by(username = uname).first()
        if new_user:
            flash('Username exists')
        else:
            phone = request.form.get('phoneno')
            email = request.form.get('email')
            pwd = request.form.get('password')
            pwd = generate_password_hash(pwd, method='sha256')
            role = request.form.get('role')
            newuser = User(username=uname,password=pwd,firstname=fname,lastname=lname,email=email,phone=phone,role=role)
            db.session.add(newuser)
            db.session.commit()
            flash('User added successfully')
 
    return redirect(url_for('auth.users'))

@auth.route('/register')
@login_required
def register():
    user = User.query.filter_by(username=current_user.username).first()
    if user.role == "Admin":
        return render_template('register.html')
    else:
        return redirect(url_for('main.index'))

@auth.route('/register', methods=['POST'])
@login_required
def register_post():
    username = request.form.get('username')
    password = request.form.get('password')
    user = User.query.filter_by(username=username).first()
    if user:
        flash('Username address already exists')
        return redirect(url_for('auth.register'))
    new_user = User(username=username, password=generate_password_hash(password, method='sha256'))
    db.session.add(new_user)
    db.session.commit()
    return redirect(url_for('auth.users'))
    #return redirect(url_for('auth.register'))

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))

@auth.route('/guest')
def guest_without_room():
    return redirect(url_for('auth.login'))

@auth.route('/guest/<roomname>')
def guest(roomname):
    return render_template('guest.html')

@auth.route('/guest/<roomname>', methods=['POST'])
def guest_meeting(roomname):
    from flask import current_app
    name = request.form.get('name')
    email = request.form.get('email')
    meetingpassword = request.form.get('meetingpassword')
    roomname = re.sub('\W+','', roomname) 
    valid = Validation()
    if valid.email(email) == False:
        flash("Invalid email address.")
        return redirect(url_for('auth.guest',roomname=roomname))

    if name or email or meetingpassword != "":
        if valid.length(name,2) == False:
            flash("Please enter a valid name.")
        meet = Meetings.query.filter_by(name=roomname).first() 
        print(meet.password)
        if meet:
            if meet.password == meetingpassword:
                new_guest = Guests(name=name, email=email,meetingid=meet.id)
                db.session.add(new_guest)
                db.session.commit()
                id = random.randint(1,101)
                avatarurl = ""
                group = ""
                appid = current_app.config['APP_ID']
                appsecret = current_app.config['APP_SECRET']
                moderator = False
                token = Token()
                jwt = token.generate(appid,appsecret,roomname,name,email,id,group,avatarurl,moderator)
                return render_template('meeting.html',avatar=avatarurl,condition=True,roomname=roomname,token=jwt,guest=True)
            else:
                flash("Invalid meeting or password")
                return redirect(url_for('auth.guest',roomname=roomname))
        else:
            flash("Invalid meeting or password")
            return redirect(url_for('auth.guest',roomname=roomname))
    else:
        flash("Please fill all details")
        return redirect(url_for('auth.guest',roomname=roomname))

@auth.route('/setup')
def setup():
    from flask import current_app
    username = current_app.config['ADMIN_USER']
    password = current_app.config['ADMIN_PASSWORD']
    user = User.query.filter_by(username=username).first()    
    if user:
        user.passsword = generate_password_hash(password, method='sha256')
        user.role = "Admin"
        db.session.commit()
    else:
        new_user = User(username=username, password=generate_password_hash(password, method='sha256'),role="admin")
        db.session.add(new_user)
        db.session.commit()
    return redirect(url_for('auth.login'))
